Golden Night — Chrome Web Store screenshots
All 5 images are PNG, 1280 x 800 pixels (16:10).
The original webpage and Golden Night popup are preserved from the submitted screenshots; the Windows browser frame/taskbar was replaced by a macOS-inspired dark browser frame.

Suggested upload order:
1. 01-Golden-Night-Enabled.png
2. 02-Golden-Night-Settings.png
3. 03-Chrome-Dark-Mode-Guide.png
4. 04-Golden-Night-Disabled.png
5. 05-Golden-Night-Help-Tip.png
