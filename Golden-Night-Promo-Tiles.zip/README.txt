Golden Night — Chrome Web Store promotional assets

1) Golden-Night-Small-Promo-440x280.jpg
   Canvas: 440 x 280 px
   Format: JPEG, RGB (no alpha channel)

2) Golden-Night-Marquee-Promo-1400x560.jpg
   Canvas: 1400 x 560 px
   Format: JPEG, RGB (no alpha channel)

Both tiles use the same black-and-gold Golden Night visual identity. The compact tile is cropped to the requested aspect ratio; the wide marquee keeps the full branded composition visible and extends the surrounding dark atmosphere to the required canvas without cropping the crescent mark or browser mockup.
